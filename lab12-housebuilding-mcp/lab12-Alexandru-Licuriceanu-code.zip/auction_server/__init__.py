# Auction server module
